<!-- rubikphish -->

<p align="center">
  <a href="https://ibb.co/T0Lyrcv"><img src="https://i.ibb.co/94tPGn8/Screenshot-512.png" alt="Screenshot-512" border="0"></a>
</p>
<h1 align="center"><b>RUBIKPHISH PHISHING TOOL.</b></h1>

<p align="center">
  <img src="https://img.shields.io/badge/Version-2.3.1-green?style=for-the-badge">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Author-rubikproxy-blue?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-Yes-darkgreen?style=flat-square">
  <img src="https://img.shields.io/badge/Maintained%3F-Yes-lightblue?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Bash-darkcyan?style=flat-square">
</p>

<p align="center"><b>It is an automated phishing tool that includes more than 30 phishing templates.</b></p>

##

<h3><p align="center">Disclaimer</p></h3>

<i>Any actions and or activities related to <b>rubikphish</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal</b> charges brought against the persons in question.

<b>This toolkit contains materials that can be potentially damaging or dangerous for social media</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b> This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here.<b>If this is your intention, then Get the hell out of here</b>!

 It only demonstrates "how phishing works".<b> You shall not misuse the information to gain unauthorized access to someones social media</b>. However you may try out this at your own risk.</i>
##

### Features
This automation tool was developed in the beginning of 2023. This tool has added some additional futures. This tool has 30 social websites and some other websites.  And if you want to add some other additional futures you can also report it in the issue we will fix it as soon as possible if you want to add some other additional futures add you can also report it in the issue
- Latest and updated login pages.
- Multiple tunneling options
  - Localhost
  - Cloudflared
  - LocalXpose
- Mask URL support 

### Important
If you need an localxpose link .You need to sign up on this https://localxpose.io/ website and give the  Access Token when you run this tool only then this link will generated.
##

### Installation

- Just, Clone this repository -
  ```
  git clone https://github.com/rubikproxy/rubikphish.git
  ```
- Now go to cloned directory and run `rubikphish.sh` 
  ```
  $ cd rubikphish
  $ chmod +x rubikphish.sh
  $ bash rubikphish.sh
  ```

- On first launch, It'll install the dependencies and it. ***rubikphish*** is installed.



<details>
  <summary><h3>Dependencies</h3></summary>
<b>rubikphish</b> requires following programs to run properly - 
- `git`
- `curl`
- `php`

> All the dependencies will be installed automatically when you run **rubikphish** for the first time.
</details>

<details>
  <summary><h3>Tested on</h3></summary>
- Ubuntu
- Debian
- Arch
- Manjaro
- Fedora
- Termux
- Kali Linux
</details>
<h3 align="center">Workflow</h3>

<h3>For reference https://youtu.be/RLeJTOmslao </h3>
<p align="center">
  <a href="https://ibb.co/MRL7GLL"><img src="https://i.ibb.co/dQyDLyy/rubikphish.png" alt="rubikphish" border="0"></a>
</p>




